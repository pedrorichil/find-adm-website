# Telegram_Stealer
You can use this Python code, to create .exe file, and use it to steal a Telegram session.
1) You need to install Python(3.8.2) on your PC.
2) Install some code editors(Visual Studio Code or Sublime Text 3)
3) Register some FTP server 
4) Open file with code editor and write your information in code (host, login, password). Save it!
5) You need to compilate this python code in exe file. I used a auto-py-to-exe (you can search this)
6) When you create a .exe file, send this file to your  victim. When he open your file, you will get 2 .zip files on your FTP server.
7) Download Telegram Portable
8) Open it, telegram will create folder "tdata" - open it. You will have folder "D877F783D5D3EF8C" - open it and replace map0 or map1 (you must use your file from tdata.zip server)
9) Open again "tdata" - search file "D877F783D5D3EF8C", delete them. Transfer a similar file from your tdata1.zip or tdata2.zip.
10) Open Telegram Portable - you will have a stolen session.



